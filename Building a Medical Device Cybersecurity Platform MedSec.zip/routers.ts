import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { storagePut } from "./storage";
import { notifyOwner } from "./_core/notification";
import * as db from "./db";
import { nanoid } from "nanoid";

// Admin-only procedure
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin access required' });
  }
  return next({ ctx });
});

// TGA Essential Principles data
const TGA_PRINCIPLES = [
  { number: 1, name: "Clinical Performance", description: "Evidence of device safety and effectiveness" },
  { number: 2, name: "Risk Management", description: "Comprehensive risk assessment and mitigation" },
  { number: 3, name: "Software Lifecycle", description: "Proper software development and maintenance processes" },
  { number: 4, name: "Cybersecurity", description: "Protection against cyber threats and vulnerabilities" },
  { number: 5, name: "Quality Management", description: "Documented quality management systems" },
  { number: 6, name: "Clinical Evidence", description: "Supporting clinical data and literature" },
  { number: 7, name: "Post-Market Surveillance", description: "Ongoing monitoring of device performance" },
  { number: 8, name: "Corrective Actions", description: "Procedures for addressing device issues" },
  { number: 9, name: "Documentation", description: "Complete technical and clinical documentation" },
  { number: 10, name: "Traceability", description: "Ability to trace devices and components" },
  { number: 11, name: "Training", description: "Appropriate training for device users" },
  { number: 12, name: "Incident Reporting", description: "Procedures for reporting adverse events" }
];

// AI Agent definitions
const AI_AGENTS = [
  { name: "Network Scanner", type: "network_scanner", description: "Discovers and maps network topology, identifies open ports and services", capabilities: ["port_scanning", "service_detection", "topology_mapping"] },
  { name: "Vulnerability Assessor", type: "vulnerability_assessor", description: "Identifies known vulnerabilities using CVE database", capabilities: ["cve_lookup", "version_detection", "patch_analysis"] },
  { name: "Web App Tester", type: "web_app_tester", description: "Tests web interfaces for common vulnerabilities", capabilities: ["xss_detection", "sql_injection", "csrf_testing"] },
  { name: "API Tester", type: "api_tester", description: "Analyzes API endpoints for security issues", capabilities: ["endpoint_fuzzing", "auth_bypass", "rate_limiting"] },
  { name: "Authentication Tester", type: "authentication_tester", description: "Tests authentication mechanisms and credential handling", capabilities: ["brute_force", "session_analysis", "mfa_testing"] },
  { name: "Encryption Analyzer", type: "encryption_analyzer", description: "Evaluates encryption implementations and key management", capabilities: ["cipher_analysis", "key_strength", "protocol_testing"] },
  { name: "Protocol Analyzer", type: "protocol_analyzer", description: "Analyzes medical device communication protocols", capabilities: ["hl7_analysis", "dicom_testing", "fhir_validation"] },
  { name: "Firmware Analyzer", type: "firmware_analyzer", description: "Examines device firmware for vulnerabilities", capabilities: ["binary_analysis", "hardcoded_creds", "update_mechanism"] },
  { name: "Configuration Auditor", type: "configuration_auditor", description: "Reviews device configurations against best practices", capabilities: ["baseline_check", "hardening_audit", "default_creds"] },
  { name: "Compliance Checker", type: "compliance_checker", description: "Validates compliance with regulatory requirements", capabilities: ["tga_check", "hipaa_audit", "gdpr_validation"] },
  { name: "Threat Modeler", type: "threat_modeler", description: "Models potential attack scenarios and threat vectors", capabilities: ["attack_surface", "threat_mapping", "risk_scoring"] },
  { name: "Penetration Tester", type: "penetration_tester", description: "Performs coordinated penetration testing", capabilities: ["exploit_testing", "privilege_escalation", "lateral_movement"] }
];

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ==================== ORGANIZATION ====================
  organization: router({
    list: protectedProcedure.query(async () => {
      return db.getOrganizations();
    }),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return db.getOrganizationById(input.id);
    }),
    create: adminProcedure.input(z.object({
      name: z.string().min(1),
      type: z.enum(["hospital", "manufacturer", "provider"]),
      address: z.string().optional(),
      contactEmail: z.string().email().optional(),
      contactPhone: z.string().optional()
    })).mutation(async ({ input }) => {
      const id = await db.createOrganization(input);
      return { id };
    }),
  }),

  // ==================== NETWORK SEGMENTS ====================
  networkSegment: router({
    list: protectedProcedure.input(z.object({ organizationId: z.number() })).query(async ({ input }) => {
      return db.getNetworkSegmentsByOrg(input.organizationId);
    }),
    create: protectedProcedure.input(z.object({
      organizationId: z.number(),
      name: z.string().min(1),
      subnet: z.string().optional(),
      vlan: z.string().optional(),
      description: z.string().optional(),
      securityLevel: z.enum(["critical", "high", "medium", "low"])
    })).mutation(async ({ input }) => {
      const id = await db.createNetworkSegment(input);
      return { id };
    }),
  }),

  // ==================== DEVICES ====================
  device: router({
    list: protectedProcedure.input(z.object({ organizationId: z.number() })).query(async ({ input }) => {
      return db.getDevicesByOrg(input.organizationId);
    }),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return db.getDeviceById(input.id);
    }),
    create: protectedProcedure.input(z.object({
      organizationId: z.number(),
      networkSegmentId: z.number().optional(),
      name: z.string().min(1),
      manufacturer: z.string().optional(),
      model: z.string().optional(),
      serialNumber: z.string().optional(),
      deviceType: z.enum(["imaging", "monitoring", "therapeutic", "diagnostic", "laboratory", "surgical", "infusion", "other"]),
      ipAddress: z.string().optional(),
      macAddress: z.string().optional(),
      firmwareVersion: z.string().optional(),
      osType: z.string().optional(),
      osVersion: z.string().optional(),
      status: z.enum(["online", "offline", "maintenance", "unknown"]),
      criticality: z.enum(["critical", "high", "medium", "low"])
    })).mutation(async ({ input }) => {
      const id = await db.createDevice(input);
      return { id };
    }),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      data: z.object({
        name: z.string().optional(),
        status: z.enum(["online", "offline", "maintenance", "unknown"]).optional(),
        criticality: z.enum(["critical", "high", "medium", "low"]).optional(),
        riskScore: z.string().optional()
      })
    })).mutation(async ({ input }) => {
      await db.updateDevice(input.id, input.data);
      return { success: true };
    }),
    stats: protectedProcedure.input(z.object({ organizationId: z.number() })).query(async ({ input }) => {
      return db.getDeviceStats(input.organizationId);
    }),
    connections: protectedProcedure.input(z.object({ deviceIds: z.array(z.number()) })).query(async ({ input }) => {
      return db.getDeviceConnections(input.deviceIds);
    }),
  }),

  // ==================== VULNERABILITIES ====================
  vulnerability: router({
    list: protectedProcedure.input(z.object({ limit: z.number().optional() })).query(async ({ input }) => {
      return db.getVulnerabilities(input.limit);
    }),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return db.getVulnerabilityById(input.id);
    }),
    create: protectedProcedure.input(z.object({
      cveId: z.string().optional(),
      title: z.string().min(1),
      description: z.string().optional(),
      cvssScore: z.string().optional(),
      cvssVector: z.string().optional(),
      severity: z.enum(["critical", "high", "medium", "low", "info"]),
      affectedSystems: z.string().optional(),
      remediation: z.string().optional()
    })).mutation(async ({ input }) => {
      const id = await db.createVulnerability(input);
      return { id };
    }),
    deviceVulnerabilities: protectedProcedure.input(z.object({ deviceId: z.number() })).query(async ({ input }) => {
      return db.getDeviceVulnerabilities(input.deviceId);
    }),
    openByOrg: protectedProcedure.input(z.object({ organizationId: z.number() })).query(async ({ input }) => {
      return db.getOpenVulnerabilitiesByOrg(input.organizationId);
    }),
    updateStatus: protectedProcedure.input(z.object({
      id: z.number(),
      status: z.enum(["open", "in_progress", "mitigated", "resolved", "accepted"])
    })).mutation(async ({ input }) => {
      await db.updateDeviceVulnerabilityStatus(input.id, input.status);
      return { success: true };
    }),
    stats: protectedProcedure.input(z.object({ organizationId: z.number() })).query(async ({ input }) => {
      return db.getVulnerabilityStats(input.organizationId);
    }),
    assignToDevice: protectedProcedure.input(z.object({
      deviceId: z.number(),
      vulnerabilityId: z.number(),
      priority: z.enum(["critical", "high", "medium", "low"])
    })).mutation(async ({ input }) => {
      const id = await db.createDeviceVulnerability({
        deviceId: input.deviceId,
        vulnerabilityId: input.vulnerabilityId,
        priority: input.priority,
        status: "open"
      });
      return { id };
    }),
  }),

  // ==================== TGA COMPLIANCE ====================
  tgaCompliance: router({
    principles: publicProcedure.query(() => TGA_PRINCIPLES),
    byDevice: protectedProcedure.input(z.object({ deviceId: z.number() })).query(async ({ input }) => {
      return db.getTgaComplianceByDevice(input.deviceId);
    }),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      status: z.enum(["compliant", "non_compliant", "partial", "not_applicable", "pending"]),
      evidence: z.string().optional(),
      notes: z.string().optional()
    })).mutation(async ({ input, ctx }) => {
      await db.updateTgaCompliance(input.id, {
        status: input.status,
        evidence: input.evidence,
        notes: input.notes,
        lastAssessedAt: new Date(),
        assessedBy: ctx.user.id
      });
      return { success: true };
    }),
    initializeForDevice: protectedProcedure.input(z.object({ deviceId: z.number() })).mutation(async ({ input }) => {
      for (const principle of TGA_PRINCIPLES) {
        await db.createTgaCompliance({
          deviceId: input.deviceId,
          principleNumber: principle.number,
          principleName: principle.name,
          status: "pending"
        });
      }
      return { success: true };
    }),
    stats: protectedProcedure.input(z.object({ organizationId: z.number() })).query(async ({ input }) => {
      return db.getTgaComplianceStats(input.organizationId);
    }),
  }),

  // ==================== COMPLIANCE REPORTS ====================
  complianceReport: router({
    list: protectedProcedure.input(z.object({ organizationId: z.number() })).query(async ({ input }) => {
      return db.getComplianceReportsByOrg(input.organizationId);
    }),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return db.getComplianceReportById(input.id);
    }),
    generate: protectedProcedure.input(z.object({
      organizationId: z.number(),
      deviceId: z.number().optional(),
      reportType: z.enum(["tga_assessment", "iso_14971", "iec_62304", "nist", "full_audit"]),
      title: z.string()
    })).mutation(async ({ input, ctx }) => {
      // Generate report using LLM
      const prompt = `Generate a comprehensive ${input.reportType.replace('_', ' ')} compliance report for a medical device cybersecurity assessment. Include:
1. Executive Summary
2. Scope and Methodology
3. Findings and Observations
4. Risk Assessment
5. Recommendations
6. Compliance Status Summary

Format the response as a structured JSON with these sections.`;

      const llmResponse = await invokeLLM({
        messages: [
          { role: "system", content: "You are a medical device cybersecurity compliance expert specializing in TGA, ISO 14971, IEC 62304, and NIST frameworks." },
          { role: "user", content: prompt }
        ]
      });

      const rawContent = llmResponse.choices[0]?.message?.content;
      const reportContent = typeof rawContent === 'string' ? rawContent : "Report generation failed";
      
      // Store report in S3
      const fileKey = `reports/${input.organizationId}/${nanoid()}-${input.reportType}.json`;
      const { url } = await storagePut(fileKey, reportContent, "application/json");

      const id = await db.createComplianceReport({
        organizationId: input.organizationId,
        deviceId: input.deviceId,
        reportType: input.reportType,
        title: input.title,
        summary: reportContent.slice(0, 500),
        fileUrl: url,
        fileKey: fileKey,
        generatedBy: ctx.user.id,
        status: "draft"
      });

      return { id, fileUrl: url };
    }),
    approve: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input, ctx }) => {
      await db.updateComplianceReport(input.id, {
        status: "approved",
        approvedBy: ctx.user.id,
        approvedAt: new Date()
      });
      return { success: true };
    }),
  }),

  // ==================== AI AGENTS ====================
  aiAgent: router({
    list: protectedProcedure.query(async () => {
      const agents = await db.getAiAgents();
      if (agents.length === 0) {
        // Initialize default agents
        for (const agent of AI_AGENTS) {
          await db.createAiAgent({
            name: agent.name,
            agentType: agent.type as any,
            description: agent.description,
            capabilities: agent.capabilities,
            defaultIntensity: "moderate",
            isActive: true
          });
        }
        return db.getAiAgents();
      }
      return agents;
    }),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return db.getAiAgentById(input.id);
    }),
    update: adminProcedure.input(z.object({
      id: z.number(),
      isActive: z.boolean().optional(),
      defaultIntensity: z.enum(["gentle", "moderate", "aggressive"]).optional()
    })).mutation(async ({ input }) => {
      await db.updateAiAgent(input.id, {
        isActive: input.isActive,
        defaultIntensity: input.defaultIntensity
      });
      return { success: true };
    }),
  }),

  // ==================== AI TEST SESSIONS ====================
  aiTestSession: router({
    list: protectedProcedure.input(z.object({ organizationId: z.number() })).query(async ({ input }) => {
      return db.getAiTestSessionsByOrg(input.organizationId);
    }),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return db.getAiTestSessionById(input.id);
    }),
    create: protectedProcedure.input(z.object({
      organizationId: z.number(),
      deviceId: z.number().optional(),
      name: z.string(),
      intensity: z.enum(["gentle", "moderate", "aggressive"]),
      agentIds: z.array(z.number())
    })).mutation(async ({ input, ctx }) => {
      const id = await db.createAiTestSession({
        organizationId: input.organizationId,
        deviceId: input.deviceId,
        name: input.name,
        intensity: input.intensity,
        agentIds: input.agentIds,
        status: "pending",
        progress: 0,
        initiatedBy: ctx.user.id
      });
      return { id };
    }),
    start: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.updateAiTestSession(input.id, {
        status: "running",
        startedAt: new Date()
      });
      return { success: true };
    }),
    updateProgress: protectedProcedure.input(z.object({
      id: z.number(),
      progress: z.number().min(0).max(100)
    })).mutation(async ({ input }) => {
      const updates: any = { progress: input.progress };
      if (input.progress >= 100) {
        updates.status = "completed";
        updates.completedAt = new Date();
      }
      await db.updateAiTestSession(input.id, updates);
      return { success: true };
    }),
    results: protectedProcedure.input(z.object({ sessionId: z.number() })).query(async ({ input }) => {
      return db.getAiTestResultsBySession(input.sessionId);
    }),
    addResult: protectedProcedure.input(z.object({
      sessionId: z.number(),
      agentId: z.number(),
      deviceId: z.number().optional(),
      testType: z.string(),
      status: z.enum(["passed", "failed", "warning", "info"]),
      severity: z.enum(["critical", "high", "medium", "low", "info"]),
      title: z.string(),
      description: z.string().optional(),
      evidence: z.string().optional(),
      recommendation: z.string().optional()
    })).mutation(async ({ input }) => {
      const id = await db.createAiTestResult(input);
      return { id };
    }),
  }),

  // ==================== SECURITY ALERTS ====================
  securityAlert: router({
    list: protectedProcedure.input(z.object({
      organizationId: z.number(),
      status: z.string().optional()
    })).query(async ({ input }) => {
      return db.getSecurityAlertsByOrg(input.organizationId, input.status);
    }),
    create: protectedProcedure.input(z.object({
      organizationId: z.number(),
      deviceId: z.number().optional(),
      alertType: z.enum(["vulnerability", "threat", "compliance", "anomaly", "incident"]),
      severity: z.enum(["critical", "high", "medium", "low", "info"]),
      title: z.string(),
      description: z.string().optional(),
      source: z.string().optional()
    })).mutation(async ({ input }) => {
      const id = await db.createSecurityAlert(input);
      
      // Send notification for critical alerts
      if (input.severity === "critical") {
        await notifyOwner({
          title: `Critical Security Alert: ${input.title}`,
          content: input.description || "A critical security alert has been triggered."
        });
      }
      
      return { id };
    }),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      status: z.enum(["new", "acknowledged", "investigating", "resolved", "dismissed"]),
      assignedTo: z.number().optional()
    })).mutation(async ({ input, ctx }) => {
      const updates: any = { status: input.status };
      if (input.assignedTo) updates.assignedTo = input.assignedTo;
      if (input.status === "resolved") {
        updates.resolvedAt = new Date();
        updates.resolvedBy = ctx.user.id;
      }
      await db.updateSecurityAlert(input.id, updates);
      return { success: true };
    }),
    stats: protectedProcedure.input(z.object({ organizationId: z.number() })).query(async ({ input }) => {
      return db.getAlertStats(input.organizationId);
    }),
  }),

  // ==================== RISK ASSESSMENT ====================
  riskAssessment: router({
    list: protectedProcedure.input(z.object({ organizationId: z.number() })).query(async ({ input }) => {
      return db.getRiskAssessmentsByOrg(input.organizationId);
    }),
    latest: protectedProcedure.input(z.object({ organizationId: z.number() })).query(async ({ input }) => {
      return db.getLatestRiskAssessment(input.organizationId);
    }),
    create: protectedProcedure.input(z.object({
      organizationId: z.number(),
      deviceId: z.number().optional(),
      assessmentType: z.enum(["device", "network", "organization", "compliance"])
    })).mutation(async ({ input, ctx }) => {
      // Calculate risk scores based on vulnerabilities and compliance
      const vulnStats = await db.getVulnerabilityStats(input.organizationId);
      const complianceStats = await db.getTgaComplianceStats(input.organizationId);
      
      const vulnerabilityScore = Math.min(100, (vulnStats.critical * 25 + vulnStats.high * 15 + vulnStats.medium * 5 + vulnStats.low * 1));
      const complianceScore = complianceStats.total > 0 
        ? ((complianceStats.compliant / complianceStats.total) * 100)
        : 0;
      const overallRiskScore = (vulnerabilityScore * 0.6 + (100 - complianceScore) * 0.4);

      const id = await db.createRiskAssessment({
        organizationId: input.organizationId,
        deviceId: input.deviceId,
        assessmentType: input.assessmentType,
        overallRiskScore: overallRiskScore.toFixed(2),
        vulnerabilityScore: vulnerabilityScore.toFixed(2),
        complianceScore: complianceScore.toFixed(2),
        threatScore: (vulnStats.critical * 10).toFixed(2),
        impactScore: (vulnStats.critical * 20 + vulnStats.high * 10).toFixed(2),
        assessedBy: ctx.user.id
      });

      return { id, overallRiskScore, vulnerabilityScore, complianceScore };
    }),
  }),

  // ==================== AUDIT LOGS ====================
  auditLog: router({
    list: protectedProcedure.input(z.object({
      organizationId: z.number(),
      limit: z.number().optional()
    })).query(async ({ input }) => {
      return db.getAuditLogs(input.organizationId, input.limit);
    }),
    create: protectedProcedure.input(z.object({
      organizationId: z.number(),
      action: z.string(),
      entityType: z.string().optional(),
      entityId: z.number().optional(),
      details: z.any().optional()
    })).mutation(async ({ input, ctx }) => {
      const id = await db.createAuditLog({
        organizationId: input.organizationId,
        userId: ctx.user.id,
        action: input.action,
        entityType: input.entityType,
        entityId: input.entityId,
        details: input.details
      });
      return { id };
    }),
  }),

  // ==================== STORED FILES ====================
  // ==================== NOTIFICATIONS ====================
  notifications: router({
    sendComplianceReport: protectedProcedure.input(z.object({
      reportId: z.number(),
      recipients: z.array(z.string().email()),
      subject: z.string().optional()
    })).mutation(async ({ input }) => {
      const report = await db.getComplianceReportById(input.reportId);
      if (!report) throw new TRPCError({ code: 'NOT_FOUND', message: 'Report not found' });

      const subject = input.subject || `TGA Compliance Report - ${report.title}`;
      const content = `A new TGA Compliance Report has been generated.\n\nReport: ${report.title}\nOverall Score: ${report.overallScore}%\n\nPlease log in to the MedSec.ai platform to view the full report.`;

      await notifyOwner({ title: subject, content });
      return { success: true, sentTo: input.recipients.length };
    }),

    sendSecurityAlert: protectedProcedure.input(z.object({
      alertId: z.number(),
      urgency: z.enum(["critical", "high", "normal"])
    })).mutation(async ({ input }) => {
      const alerts = await db.getSecurityAlertsByOrg(1);
      const alert = alerts.find(a => a.id === input.alertId);
      if (!alert) throw new TRPCError({ code: 'NOT_FOUND', message: 'Alert not found' });

      const prefix = input.urgency === 'critical' ? '🚨 CRITICAL: ' : input.urgency === 'high' ? '⚠️ HIGH: ' : '';
      const title = `${prefix}Security Alert - ${alert.title}`;
      const content = `${alert.description}\n\nSeverity: ${alert.severity}\nDevice: ${alert.deviceId || 'N/A'}\nDetected: ${alert.createdAt}\n\nPlease investigate immediately.`;

      await notifyOwner({ title, content });
      return { success: true };
    }),

    testNotification: adminProcedure.mutation(async () => {
      await notifyOwner({
        title: 'MedSec.ai Test Notification',
        content: 'This is a test notification from the MedSec.ai platform. If you received this, notifications are working correctly.'
      });
      return { success: true };
    }),
  }),

  storedFile: router({
    list: protectedProcedure.input(z.object({
      organizationId: z.number(),
      fileType: z.string().optional()
    })).query(async ({ input }) => {
      return db.getStoredFilesByOrg(input.organizationId, input.fileType);
    }),
    upload: protectedProcedure.input(z.object({
      organizationId: z.number(),
      fileType: z.enum(["compliance_report", "audit_evidence", "test_result", "device_doc", "other"]),
      fileName: z.string(),
      content: z.string(), // Base64 encoded
      mimeType: z.string()
    })).mutation(async ({ input, ctx }) => {
      const buffer = Buffer.from(input.content, 'base64');
      const fileKey = `files/${input.organizationId}/${nanoid()}-${input.fileName}`;
      const { url } = await storagePut(fileKey, buffer, input.mimeType);

      const id = await db.createStoredFile({
        organizationId: input.organizationId,
        fileType: input.fileType,
        fileName: input.fileName,
        fileKey: fileKey,
        fileUrl: url,
        mimeType: input.mimeType,
        fileSize: buffer.length,
        uploadedBy: ctx.user.id
      });

      return { id, fileUrl: url };
    }),
  }),

  // ==================== DASHBOARD ====================
  dashboard: router({
    stats: protectedProcedure.input(z.object({ organizationId: z.number() })).query(async ({ input }) => {
      return db.getDashboardStats(input.organizationId);
    }),
  }),

  // ==================== USERS (Admin) ====================
  users: router({
    list: adminProcedure.query(async () => {
      return db.getAllUsers();
    }),
    updateRole: adminProcedure.input(z.object({
      userId: z.number(),
      role: z.enum(["user", "admin", "analyst", "auditor"])
    })).mutation(async ({ input }) => {
      await db.updateUserRole(input.userId, input.role);
      return { success: true };
    }),
  }),

  // ==================== LLM ANALYSIS ====================
  llmAnalysis: router({
    analyzeVulnerability: protectedProcedure.input(z.object({
      vulnerabilityId: z.number(),
      deviceContext: z.string().optional()
    })).mutation(async ({ input }) => {
      const vuln = await db.getVulnerabilityById(input.vulnerabilityId);
      if (!vuln) throw new TRPCError({ code: 'NOT_FOUND' });

      const response = await invokeLLM({
        messages: [
          { role: "system", content: "You are a medical device cybersecurity expert. Analyze vulnerabilities and provide actionable remediation recommendations specific to healthcare environments." },
          { role: "user", content: `Analyze this vulnerability for a medical device:
CVE: ${vuln.cveId || 'N/A'}
Title: ${vuln.title}
Description: ${vuln.description || 'N/A'}
CVSS Score: ${vuln.cvssScore || 'N/A'}
Severity: ${vuln.severity}
${input.deviceContext ? `Device Context: ${input.deviceContext}` : ''}

Provide:
1. Risk assessment specific to medical devices
2. Patient safety implications
3. Step-by-step remediation plan
4. Temporary mitigation measures
5. Compliance impact (TGA, HIPAA, etc.)` }
        ]
      });

      return {
        analysis: response.choices[0]?.message?.content || "Analysis failed"
      };
    }),

    generateRemediation: protectedProcedure.input(z.object({
      vulnerabilities: z.array(z.object({
        title: z.string(),
        severity: z.string(),
        cvssScore: z.string().optional()
      }))
    })).mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "You are a medical device cybersecurity expert specializing in vulnerability remediation for healthcare environments." },
          { role: "user", content: `Generate a prioritized remediation plan for these vulnerabilities:
${input.vulnerabilities.map((v, i) => `${i + 1}. ${v.title} (${v.severity}, CVSS: ${v.cvssScore || 'N/A'})`).join('\n')}

Provide:
1. Prioritized remediation order
2. Resource requirements
3. Timeline estimates
4. Risk mitigation during remediation
5. Verification steps` }
        ]
      });

      return {
        plan: response.choices[0]?.message?.content || "Plan generation failed"
      };
    }),

    explainRisk: protectedProcedure.input(z.object({
      riskScore: z.number(),
      context: z.string()
    })).mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "You are a medical device cybersecurity expert. Explain security risks in clear, non-technical language for healthcare administrators." },
          { role: "user", content: `Explain this security risk in plain language:
Risk Score: ${input.riskScore}/100
Context: ${input.context}

Provide:
1. What this risk means in practical terms
2. Potential impact on patient care
3. Business implications
4. Recommended actions for leadership` }
        ]
      });

      return {
        explanation: response.choices[0]?.message?.content || "Explanation failed"
      };
    }),
  }),
});

export type AppRouter = typeof appRouter;
