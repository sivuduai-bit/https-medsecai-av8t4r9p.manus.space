import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock user for authenticated context
type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user-123",
    email: "security@hospital.com",
    name: "Security Admin",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("MedSec.ai Backend Tests", () => {
  describe("auth.me", () => {
    it("returns user data when authenticated", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.auth.me();

      expect(result).toBeDefined();
      expect(result?.email).toBe("security@hospital.com");
      expect(result?.name).toBe("Security Admin");
      expect(result?.role).toBe("admin");
    });

    it("returns null when not authenticated", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.auth.me();

      expect(result).toBeNull();
    });
  });

  describe("tgaCompliance router", () => {
    it("principles returns 12 TGA Essential Principles", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.tgaCompliance.principles();

      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBe(12);
      
      // Check structure of first principle
      expect(result[0]).toHaveProperty("number");
      expect(result[0]).toHaveProperty("name");
      expect(result[0]).toHaveProperty("description");
      expect(result[0].number).toBe(1);
      expect(result[0].name).toBe("Clinical Performance");
    });

    it("all 12 principles have correct structure", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.tgaCompliance.principles();

      result.forEach((principle, index) => {
        expect(principle.number).toBe(index + 1);
        expect(typeof principle.name).toBe("string");
        expect(typeof principle.description).toBe("string");
        expect(principle.name.length).toBeGreaterThan(0);
      });
    });

    it("includes all key TGA principles", async () => {
      const ctx = createPublicContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.tgaCompliance.principles();
      const principleNames = result.map(p => p.name);

      expect(principleNames).toContain("Clinical Performance");
      expect(principleNames).toContain("Risk Management");
      expect(principleNames).toContain("Software Lifecycle");
      expect(principleNames).toContain("Cybersecurity");
      expect(principleNames).toContain("Quality Management");
      expect(principleNames).toContain("Post-Market Surveillance");
    });
  });

  describe("dashboard router", () => {
    it("stats returns dashboard statistics with correct structure", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.dashboard.stats({ organizationId: 1 });

      // Check top-level structure
      expect(result).toHaveProperty("devices");
      expect(result).toHaveProperty("vulnerabilities");
      expect(result).toHaveProperty("compliance");
      expect(result).toHaveProperty("alerts");

      // Check devices sub-structure
      expect(result.devices).toHaveProperty("total");
      expect(result.devices).toHaveProperty("online");
      expect(result.devices).toHaveProperty("offline");
      expect(result.devices).toHaveProperty("critical");
      expect(typeof result.devices.total).toBe("number");
    });
  });
});
