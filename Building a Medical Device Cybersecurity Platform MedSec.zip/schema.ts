import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json, decimal, boolean } from "drizzle-orm/mysql-core";

// ==================== USER & AUTH ====================
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "analyst", "auditor"]).default("user").notNull(),
  organizationId: int("organizationId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ==================== ORGANIZATIONS ====================
export const organizations = mysqlTable("organizations", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["hospital", "manufacturer", "provider"]).default("hospital").notNull(),
  address: text("address"),
  contactEmail: varchar("contactEmail", { length: 320 }),
  contactPhone: varchar("contactPhone", { length: 50 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Organization = typeof organizations.$inferSelect;
export type InsertOrganization = typeof organizations.$inferInsert;

// ==================== NETWORK SEGMENTS ====================
export const networkSegments = mysqlTable("network_segments", {
  id: int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  subnet: varchar("subnet", { length: 50 }),
  vlan: varchar("vlan", { length: 20 }),
  description: text("description"),
  securityLevel: mysqlEnum("securityLevel", ["critical", "high", "medium", "low"]).default("medium").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type NetworkSegment = typeof networkSegments.$inferSelect;
export type InsertNetworkSegment = typeof networkSegments.$inferInsert;

// ==================== MEDICAL DEVICES ====================
export const devices = mysqlTable("devices", {
  id: int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull(),
  networkSegmentId: int("networkSegmentId"),
  name: varchar("name", { length: 255 }).notNull(),
  manufacturer: varchar("manufacturer", { length: 255 }),
  model: varchar("model", { length: 255 }),
  serialNumber: varchar("serialNumber", { length: 100 }),
  deviceType: mysqlEnum("deviceType", ["imaging", "monitoring", "therapeutic", "diagnostic", "laboratory", "surgical", "infusion", "other"]).default("other").notNull(),
  ipAddress: varchar("ipAddress", { length: 45 }),
  macAddress: varchar("macAddress", { length: 17 }),
  firmwareVersion: varchar("firmwareVersion", { length: 100 }),
  osType: varchar("osType", { length: 100 }),
  osVersion: varchar("osVersion", { length: 100 }),
  status: mysqlEnum("status", ["online", "offline", "maintenance", "unknown"]).default("unknown").notNull(),
  riskScore: decimal("riskScore", { precision: 5, scale: 2 }).default("0.00"),
  criticality: mysqlEnum("criticality", ["critical", "high", "medium", "low"]).default("medium").notNull(),
  lastSeen: timestamp("lastSeen"),
  discoveredAt: timestamp("discoveredAt").defaultNow().notNull(),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Device = typeof devices.$inferSelect;
export type InsertDevice = typeof devices.$inferInsert;

// ==================== DEVICE CONNECTIONS ====================
export const deviceConnections = mysqlTable("device_connections", {
  id: int("id").autoincrement().primaryKey(),
  sourceDeviceId: int("sourceDeviceId").notNull(),
  targetDeviceId: int("targetDeviceId").notNull(),
  connectionType: mysqlEnum("connectionType", ["network", "bluetooth", "serial", "usb", "wireless"]).default("network").notNull(),
  protocol: varchar("protocol", { length: 50 }),
  port: int("port"),
  isEncrypted: boolean("isEncrypted").default(false),
  lastActivity: timestamp("lastActivity"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DeviceConnection = typeof deviceConnections.$inferSelect;
export type InsertDeviceConnection = typeof deviceConnections.$inferInsert;

// ==================== VULNERABILITIES ====================
export const vulnerabilities = mysqlTable("vulnerabilities", {
  id: int("id").autoincrement().primaryKey(),
  cveId: varchar("cveId", { length: 20 }),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description"),
  cvssScore: decimal("cvssScore", { precision: 3, scale: 1 }),
  cvssVector: varchar("cvssVector", { length: 100 }),
  severity: mysqlEnum("severity", ["critical", "high", "medium", "low", "info"]).default("medium").notNull(),
  affectedSystems: text("affectedSystems"),
  remediation: text("remediation"),
  references: json("references"),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Vulnerability = typeof vulnerabilities.$inferSelect;
export type InsertVulnerability = typeof vulnerabilities.$inferInsert;

// ==================== DEVICE VULNERABILITIES ====================
export const deviceVulnerabilities = mysqlTable("device_vulnerabilities", {
  id: int("id").autoincrement().primaryKey(),
  deviceId: int("deviceId").notNull(),
  vulnerabilityId: int("vulnerabilityId").notNull(),
  status: mysqlEnum("status", ["open", "in_progress", "mitigated", "resolved", "accepted"]).default("open").notNull(),
  priority: mysqlEnum("priority", ["critical", "high", "medium", "low"]).default("medium").notNull(),
  assignedTo: int("assignedTo"),
  detectedAt: timestamp("detectedAt").defaultNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DeviceVulnerability = typeof deviceVulnerabilities.$inferSelect;
export type InsertDeviceVulnerability = typeof deviceVulnerabilities.$inferInsert;

// ==================== TGA COMPLIANCE ====================
export const tgaCompliance = mysqlTable("tga_compliance", {
  id: int("id").autoincrement().primaryKey(),
  deviceId: int("deviceId").notNull(),
  principleNumber: int("principleNumber").notNull(), // 1-12
  principleName: varchar("principleName", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["compliant", "non_compliant", "partial", "not_applicable", "pending"]).default("pending").notNull(),
  evidence: text("evidence"),
  notes: text("notes"),
  lastAssessedAt: timestamp("lastAssessedAt"),
  assessedBy: int("assessedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TgaCompliance = typeof tgaCompliance.$inferSelect;
export type InsertTgaCompliance = typeof tgaCompliance.$inferInsert;

// ==================== COMPLIANCE REPORTS ====================
export const complianceReports = mysqlTable("compliance_reports", {
  id: int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull(),
  deviceId: int("deviceId"),
  reportType: mysqlEnum("reportType", ["tga_assessment", "iso_14971", "iec_62304", "nist", "full_audit"]).default("tga_assessment").notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  summary: text("summary"),
  findings: json("findings"),
  recommendations: json("recommendations"),
  overallScore: decimal("overallScore", { precision: 5, scale: 2 }),
  status: mysqlEnum("status", ["draft", "pending_review", "approved", "archived"]).default("draft").notNull(),
  fileUrl: text("fileUrl"),
  fileKey: varchar("fileKey", { length: 500 }),
  generatedBy: int("generatedBy"),
  approvedBy: int("approvedBy"),
  approvedAt: timestamp("approvedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ComplianceReport = typeof complianceReports.$inferSelect;
export type InsertComplianceReport = typeof complianceReports.$inferInsert;

// ==================== AI AGENTS ====================
export const aiAgents = mysqlTable("ai_agents", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  agentType: mysqlEnum("agentType", [
    "network_scanner",
    "vulnerability_assessor",
    "web_app_tester",
    "api_tester",
    "authentication_tester",
    "encryption_analyzer",
    "protocol_analyzer",
    "firmware_analyzer",
    "configuration_auditor",
    "compliance_checker",
    "threat_modeler",
    "penetration_tester"
  ]).notNull(),
  description: text("description"),
  capabilities: json("capabilities"),
  defaultIntensity: mysqlEnum("defaultIntensity", ["gentle", "moderate", "aggressive"]).default("moderate").notNull(),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AiAgent = typeof aiAgents.$inferSelect;
export type InsertAiAgent = typeof aiAgents.$inferInsert;

// ==================== AI TEST SESSIONS ====================
export const aiTestSessions = mysqlTable("ai_test_sessions", {
  id: int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull(),
  deviceId: int("deviceId"),
  name: varchar("name", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["pending", "running", "paused", "completed", "failed", "cancelled"]).default("pending").notNull(),
  intensity: mysqlEnum("intensity", ["gentle", "moderate", "aggressive"]).default("moderate").notNull(),
  agentIds: json("agentIds"), // Array of agent IDs involved
  progress: int("progress").default(0), // 0-100
  findings: json("findings"),
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  initiatedBy: int("initiatedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AiTestSession = typeof aiTestSessions.$inferSelect;
export type InsertAiTestSession = typeof aiTestSessions.$inferInsert;

// ==================== AI TEST RESULTS ====================
export const aiTestResults = mysqlTable("ai_test_results", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  agentId: int("agentId").notNull(),
  deviceId: int("deviceId"),
  testType: varchar("testType", { length: 100 }).notNull(),
  status: mysqlEnum("status", ["passed", "failed", "warning", "info"]).default("info").notNull(),
  severity: mysqlEnum("severity", ["critical", "high", "medium", "low", "info"]).default("info").notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description"),
  evidence: text("evidence"),
  recommendation: text("recommendation"),
  rawOutput: json("rawOutput"),
  executedAt: timestamp("executedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AiTestResult = typeof aiTestResults.$inferSelect;
export type InsertAiTestResult = typeof aiTestResults.$inferInsert;

// ==================== SECURITY ALERTS ====================
export const securityAlerts = mysqlTable("security_alerts", {
  id: int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull(),
  deviceId: int("deviceId"),
  alertType: mysqlEnum("alertType", ["vulnerability", "threat", "compliance", "anomaly", "incident"]).default("vulnerability").notNull(),
  severity: mysqlEnum("severity", ["critical", "high", "medium", "low", "info"]).default("medium").notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description"),
  source: varchar("source", { length: 100 }),
  status: mysqlEnum("status", ["new", "acknowledged", "investigating", "resolved", "dismissed"]).default("new").notNull(),
  assignedTo: int("assignedTo"),
  resolvedAt: timestamp("resolvedAt"),
  resolvedBy: int("resolvedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SecurityAlert = typeof securityAlerts.$inferSelect;
export type InsertSecurityAlert = typeof securityAlerts.$inferInsert;

// ==================== AUDIT LOGS ====================
export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId"),
  userId: int("userId"),
  action: varchar("action", { length: 100 }).notNull(),
  entityType: varchar("entityType", { length: 100 }),
  entityId: int("entityId"),
  details: json("details"),
  ipAddress: varchar("ipAddress", { length: 45 }),
  userAgent: text("userAgent"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

// ==================== STORED FILES ====================
export const storedFiles = mysqlTable("stored_files", {
  id: int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull(),
  fileType: mysqlEnum("fileType", ["compliance_report", "audit_evidence", "test_result", "device_doc", "other"]).default("other").notNull(),
  fileName: varchar("fileName", { length: 500 }).notNull(),
  fileKey: varchar("fileKey", { length: 500 }).notNull(),
  fileUrl: text("fileUrl").notNull(),
  mimeType: varchar("mimeType", { length: 100 }),
  fileSize: int("fileSize"),
  version: int("version").default(1),
  parentId: int("parentId"), // For versioning
  uploadedBy: int("uploadedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type StoredFile = typeof storedFiles.$inferSelect;
export type InsertStoredFile = typeof storedFiles.$inferInsert;

// ==================== RISK ASSESSMENTS ====================
export const riskAssessments = mysqlTable("risk_assessments", {
  id: int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull(),
  deviceId: int("deviceId"),
  assessmentType: mysqlEnum("assessmentType", ["device", "network", "organization", "compliance"]).default("device").notNull(),
  overallRiskScore: decimal("overallRiskScore", { precision: 5, scale: 2 }),
  vulnerabilityScore: decimal("vulnerabilityScore", { precision: 5, scale: 2 }),
  complianceScore: decimal("complianceScore", { precision: 5, scale: 2 }),
  threatScore: decimal("threatScore", { precision: 5, scale: 2 }),
  impactScore: decimal("impactScore", { precision: 5, scale: 2 }),
  riskFactors: json("riskFactors"),
  recommendations: json("recommendations"),
  assessedBy: int("assessedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type RiskAssessment = typeof riskAssessments.$inferSelect;
export type InsertRiskAssessment = typeof riskAssessments.$inferInsert;
